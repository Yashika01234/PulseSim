# PulseSim — Monte Carlo System Reliability Simulator

PulseSim is a full-stack SWE + ML project. It uses Monte Carlo simulation to estimate system latency and SLO violation risk under uncertain traffic and server failures. Random Forest models predict SLO violation risk and p95 latency.

## Features
- Monte Carlo traffic, traffic-spike and server-failure simulation
- p50, p95, p99 latency and utilization metrics
- Estimated SLO violation probability with 95% confidence interval
- Random Forest classifier and regressor
- Model accuracy, latency MAE and feature importance
- React dashboard with interactive controls and charts
- FastAPI backend and automatically generated API docs

## Stack
React, Vite, Recharts, Python, FastAPI, NumPy, Pandas, Scikit-learn.

## Structure
```text
PulseSim/
  backend/app/main.py
  backend/app/simulator.py
  backend/app/ml.py
  backend/requirements.txt
  frontend/src/App.jsx
  frontend/src/main.jsx
  frontend/src/style.css
  frontend/package.json
  frontend/index.html
```

## Run on Windows in VS Code

You need Python 3.10+ and Node.js 18+.

### Backend terminal
```powershell
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```
API: http://localhost:8000  
Interactive docs: http://localhost:8000/docs

### Frontend — open a SECOND terminal
```powershell
cd frontend
npm install
npm run dev
```
Open the Vite URL, normally http://localhost:5173. Keep both terminals running.

## How to demonstrate
1. Adjust request rate and server replicas.
2. Increase traffic-spike and server-failure probabilities.
3. Increase Monte Carlo trial count and run the simulation.
4. Explain p95 latency and SLO violation probability.
5. Compare simulation metrics with ML predictions.
6. Explain feature importance and model accuracy.

## Method
Each Monte Carlo trial samples incoming traffic, spike events, failed replicas and service-time variation. A trial violates the SLO when its simulated latency exceeds 300 ms.

`P(SLO violation) = violating trials / total trials`

A Random Forest classifier predicts whether a scenario's estimated risk exceeds the project's 20% threshold. A Random Forest regressor predicts p95 latency.

## Assumptions and limitations
This academic prototype uses a simplified capacity assumption of 250 requests/second per healthy replica and a 300 ms latency threshold. Training data is synthetic, so reported model metrics do not establish production accuracy. It does not perform real HTTP load tests or connect to production telemetry. Validate assumptions against real measurements before operational use.

## Future enhancements
PostgreSQL persistence, Redis caching, Celery background jobs, Locust load testing, cost-aware autoscaling, Docker Compose and CI tests.

## Author
Your Name — B.Tech, Electronics and Communication Engineering.
