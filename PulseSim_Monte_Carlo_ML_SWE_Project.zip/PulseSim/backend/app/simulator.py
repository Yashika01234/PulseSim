import numpy as np

def run_monte_carlo(trials=10000, request_rate=500, replicas=3,
                    spike_probability=.08, server_failure_probability=.01, seed=42):
    rng = np.random.default_rng(seed)
    n = int(np.clip(trials, 100, 100000))
    replicas = int(np.clip(replicas, 1, 100))
    traffic = rng.lognormal(np.log(max(request_rate, 1)), .18, n)
    spikes = rng.random(n) < spike_probability
    traffic[spikes] *= rng.uniform(1.5, 4.0, spikes.sum())
    failed = rng.binomial(replicas, server_failure_probability, n)
    healthy = np.maximum(replicas - failed, 0)
    capacity = np.maximum(healthy * 250.0, 1.0)
    utilization = traffic / capacity
    service_noise = rng.lognormal(0, .22, n)
    latency = 45 * service_noise / np.maximum(1 - np.minimum(utilization, .98), .02)
    overloaded = utilization >= 1
    latency[overloaded] *= rng.uniform(1.5, 3.0, overloaded.sum())
    violations = latency > 300
    error_rate = np.clip(np.maximum(utilization - 1, 0) * .35 + (failed / replicas) * .02, 0, 1)
    risk = float(violations.mean())
    ci = 1.96 * np.sqrt(risk * (1-risk) / n)
    sample_idx = np.linspace(0, n-1, min(300, n), dtype=int)
    samples = [{"trial": int(i+1), "traffic_rps": round(float(traffic[i]),2),
                "latency_ms": round(float(latency[i]),2),
                "utilization": round(float(utilization[i]),3),
                "failed_servers": int(failed[i]),
                "slo_violation": bool(violations[i])} for i in sample_idx]
    return {
        "trials": n, "risk_probability": risk, "risk_percent": round(risk*100,2),
        "latency_p50_ms": round(float(np.percentile(latency,50)),2),
        "latency_p95_ms": round(float(np.percentile(latency,95)),2),
        "latency_p99_ms": round(float(np.percentile(latency,99)),2),
        "mean_utilization": round(float(utilization.mean()),3),
        "mean_error_rate": round(float(error_rate.mean()),5),
        "mean_failed_servers": round(float(failed.mean()),3),
        "confidence_interval_95": [round(max(0,risk-ci)*100,2), round(min(1,risk+ci)*100,2)],
        "samples": samples
    }
