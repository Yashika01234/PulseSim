from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from .simulator import run_monte_carlo
from .ml import predict

app = FastAPI(title="PulseSim API", version="1.0.0",
 description="Monte Carlo reliability simulation and ML prediction API")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"],
 allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class Scenario(BaseModel):
    request_rate: float = Field(500, ge=1, le=100000)
    replicas: int = Field(3, ge=1, le=100)
    spike_probability: float = Field(.08, ge=0, le=1)
    server_failure_probability: float = Field(.01, ge=0, le=1)
    trials: int = Field(10000, ge=100, le=100000)
    seed: int = 42

@app.get("/")
def health():
    return {"status":"ok","service":"PulseSim API"}

@app.post("/api/simulate")
def simulate(s: Scenario):
    return run_monte_carlo(s.trials,s.request_rate,s.replicas,
        s.spike_probability,s.server_failure_probability,s.seed)

@app.post("/api/predict")
def prediction(s: Scenario):
    return predict(s.request_rate,s.replicas,s.spike_probability,s.server_failure_probability)
