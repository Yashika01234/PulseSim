from functools import lru_cache
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, mean_absolute_error

FEATURES = ["request_rate", "replicas", "spike_probability", "server_failure_probability"]

@lru_cache(maxsize=1)
def models():
    rng = np.random.default_rng(19)
    n = 5000
    X = pd.DataFrame({
        "request_rate": rng.uniform(100,5000,n),
        "replicas": rng.integers(1,21,n),
        "spike_probability": rng.uniform(0,.3,n),
        "server_failure_probability": rng.uniform(0,.1,n)
    })
    load = X.request_rate / (X.replicas * 250)
    estimated_p95 = 45 / np.maximum(1-np.minimum(load*(1+X.spike_probability*2),.98),.02)
    estimated_p95 *= (1 + X.server_failure_probability*X.replicas*.8)
    y_class = (estimated_p95 > 300).astype(int)
    Xtr, Xte, ytr, yte = train_test_split(X,y_class,test_size=.2,random_state=42,stratify=y_class)
    _, _, yrtr, yrte = train_test_split(X,estimated_p95,test_size=.2,random_state=42)
    clf = RandomForestClassifier(n_estimators=120,max_depth=12,random_state=42,class_weight="balanced")
    reg = RandomForestRegressor(n_estimators=120,max_depth=12,random_state=42,n_jobs=-1)
    clf.fit(Xtr,ytr); reg.fit(Xtr,yrtr)
    return clf, reg, accuracy_score(yte,clf.predict(Xte)), mean_absolute_error(yrte,reg.predict(Xte))

def predict(request_rate, replicas, spike_probability, server_failure_probability):
    clf, reg, acc, mae = models()
    X = pd.DataFrame([dict(request_rate=request_rate, replicas=replicas,
        spike_probability=spike_probability, server_failure_probability=server_failure_probability)])
    return {
        "predicted_slo_violation_probability": round(float(clf.predict_proba(X)[0][1]),4),
        "predicted_p95_latency_ms": round(float(reg.predict(X)[0]),2),
        "model_accuracy": round(float(acc),4),
        "latency_mae_ms": round(float(mae),2),
        "feature_importance": dict(zip(FEATURES, clf.feature_importances_.tolist()))
    }
